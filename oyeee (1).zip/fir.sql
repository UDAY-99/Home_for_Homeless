Create table login(
    email varchar(45) NOT NULL,
    pass varchar(8) NOT NULL
)